
SELECT	* 
FROM	emp
WHERE	empname = 'Amit' AND deptid = 1;

SELECT	* 
FROM	emp
WHERE	deptid = 2 AND empname LIKE '%s%';


SELECT	* 
FROM	emp
WHERE	deptid <> 3;

SELECT	* 
FROM	emp
WHERE empid <> 1 AND deptid <> 1;

SELECT	* 
FROM	emp
WHERE	empid > 4;

SELECT	* 
FROM	emp
WHERE	deptid > 1 AND empid = 5;

SELECT	* 
FROM	emp
WHERE	empid < 6;

SELECT	* 
FROM	emp
WHERE	empid < 4 OR deptid = 3;

SELECT	*
FROM	emp
WHERE	deptid IN (1, 2);

SELECT	* 
FROM	emp
WHERE	empname IN ('John', 'Nitin');

SELECT	*
FROM	emp
WHERE	deptid NOT IN (1, 2);

SELECT	* 
FROM	emp
WHERE	empname NOT IN ('Peter', 'Rita');

SELECT	* 
FROM	emp
WHERE	empname LIKE 'A%';

SELECT	* 
FROM	dept
WHERE	deptname LIKE '%H%';

SELECT	* 
FROM	emp
WHERE	empid BETWEEN 2 AND 7;

SELECT	*	
FROM	dept
WHERE	deptid BETWEEN 1 AND 5;

SELECT	* 
FROM	emp
WHERE	empname NOT LIKE 'S%';

SELECT	* 
FROM	dept
WHERE	deptname NOT LIKE '%IT%';





