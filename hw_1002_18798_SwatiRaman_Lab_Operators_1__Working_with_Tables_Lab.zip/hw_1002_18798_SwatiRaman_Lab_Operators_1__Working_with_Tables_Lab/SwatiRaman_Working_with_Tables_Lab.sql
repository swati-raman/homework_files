USE SwatiRaman;

--Table creation - Coaches
CREATE TABLE coaches
(
	coachid int null,
	coachname varchar(50) null,
	coachtype varchar(50) null,
	startdate datetime null
);

INSERT INTO	dbo.players 
VALUES (1,'Running Back',22,'1/1/2012');

INSERT INTO	dbo.Coaches 
VALUES (1,'John Starks','Running Back Coach','1/1/2012');


INSERT INTO dbo.Players 
VALUES (2, 'Quarterback', 20, '2013-02-10');
INSERT INTO dbo.Players
VALUES (3, 'Wide Receiver', 9, '2014-03-15');
INSERT INTO dbo.Players
VALUES (4, 'Tight End', 27, '2015-04-20');
INSERT INTO dbo.Players 
VALUES (5, 'Linebacker', 14, '2016-05-25');
INSERT INTO dbo.Players 
VALUES (6, 'Defensive End', 19, '2017-06-30');
INSERT INTO dbo.Players 
VALUES (7, 'Cornerback', 21, '2018-07-05');
INSERT INTO dbo.Players 
VALUES (8, 'Safety', 15, '2019-08-10');
INSERT INTO dbo.Players 
VALUES (9, 'Kicker', 4, '2020-09-15');
INSERT INTO dbo.Players 
VALUES (10, 'Punter', 6, '2021-10-20');


INSERT INTO dbo.coaches 
VALUES 
(2, 'Mike Adams', 'Wide Receiver Coach', '5/14/2013'),
(3, 'David Brown', 'Quarterback Coach', '8/22/2014'),
(4, 'James Lee', 'Defensive Coordinator', '6/30/2015'),
(5, 'Robert Smith', 'Offensive Line Coach', '9/15/2016'),
(6, 'Chris Johnson', 'Special Teams Coach', '2/1/2017'),
(7, 'Thomas Clark', 'Linebacker Coach', '3/11/2018'),
(8, 'William Davis', 'Cornerback Coach', '4/23/2019'),
(9, 'Andrew Martin', 'Tight End Coach', '7/19/2020'),
(10, 'Samuel Walker', 'Safety Coach', '10/5/2021');

--II.Retrieve All Players with Jersey numbers in the 20�s
SELECT	*
FROM	players
WHERE	jerseynumber BETWEEN 20 AND 29;

--III.Retrieve All Coaches with CoachID less than 5.
SELECT	*
FROM	coaches
WHERE	coachid < 5;

--IV.Retrieve All players who joined the team this year.
SELECT	*
FROM	players
WHERE	YEAR(startdate) = 2025;

--V.Retrieve All coaches who joined the team last year.
SELECT	*
FROM	coaches
WHERE	YEAR(startdate) = 2024;

--VI.Retrieve All players with PlayerID greater than 5.
SELECT	*
FROM	players
WHERE	playerid > 5;

--VII.Retrieve All running backs.
SELECT	* 
FROM	players
WHERE position = 'Running Back';

--VIII.Retrieve All Quarter Back Coaches.
SELECT	* 
FROM	coaches
WHERE	coachtype = 'Quarterback Coach';

 --e.Create a player backup table (player_backup) using the SELECT INTO statement.
SELECT	*
INTO	player_backup
FROM	players;

--f.Create a coach backup table (coach_backup) using the SELECT INTO statement.
SELECT	*
INTO	coach_backup
FROM	coaches;