/*
Name:	Swati Raman
Lesson:  Revised_Query_Editor_Features_Lab
Date:	02/11/2025
*/

--a.  Retrieve all records from Employee table
SELECT *
FROM	employee;

--b.  Retrieve all records from Emp table
SELECT *
FROM	emp;

--c.  Retrieve all records from dept table
SELECT *
FROM	dept;

--d.  Retrieve all columns from the emp table where first name = John
SELECT *
FROM	emp 
WHERE	empname = 'John';

--e.  Retrieve empname and Salary from the Employee table where Salary is greater than $30,000
SELECT	empname,salary
FROM	employee
WHERE	salary > 30000;

--f.  Find the deptname of deptid 1
SELECT	deptname
FROM	dept
WHERE	deptid = 1;

--g.  Select all empid�s from Employee table where mgrid = 5
SELECT	empid
FROM	employee
WHERE	mgrid = 5;

--h.  Select all empid�s from Phone table where employee does not have a phone number.
SELECT	empid
FROM	phone
WHERE	phone is null;