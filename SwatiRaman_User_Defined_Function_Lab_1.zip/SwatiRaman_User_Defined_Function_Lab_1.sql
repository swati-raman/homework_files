/*
Name - Swati Raman
Lesson - Working_with_Variables_Lab_1
Date - 02/16/2025
*/

Use AdventureWorks2019;

SELECT	* 
FROM	[HumanResources].[Employee];

--1. Create a UDF that accepts EmployeeID (2012: BusinessEntityID) and returns UserLoginID. 
--The UserLoginID is the last part of the LogID column.  It�s only the part that comes after the \
GO

CREATE FUNCTION func_userloginid(@employeeid INT)
RETURNS VARCHAR(20)
AS
	BEGIN
		DECLARE @UserLoginID VARCHAR(20)
			SELECT	@UserLoginID = SUBSTRING(LoginID,CHARINDEX('\',LoginID)+1,LEN(LoginID)-CHARINDEX('\',LoginID))
			FROM	[HumanResources].[Employee] 
			WHERE	BusinessEntityID = @employeeid;
		RETURN @UserLoginID;
	END
GO

SELECT [dbo].[func_userloginid](1);

--2.Create a UDF that accepts EmployeeID (2012: BusinessEntityID) and returns their age.

GO 

CREATE FUNCTION func_userage(@employeeid INT)
RETURNS INT
AS
	BEGIN
		DECLARE @userage INT
			SELECT	@userage = DATEDIFF(YEAR,BirthDate,GETDATE())
			FROM	[HumanResources].[Employee] 
			WHERE	BusinessEntityID = @employeeid;
		RETURN @userage;
	END
GO


SELECT [dbo].[func_userage](1);

--3.Create a UDF that accepts the Gender and returns the avg VacationHours
GO 

CREATE FUNCTION func_averagehours(@gender VARCHAR(1))
RETURNS INT
AS
	BEGIN
		DECLARE @avgage INT
			SELECT	@avgage = AVG(VacationHours)
			FROM	[HumanResources].[Employee]
			WHERE	Gender = @gender
			GROUP BY Gender;
		RETURN @avgage;
	END
GO

SELECT [dbo].[func_averagehours]('F');

--4.Create a UDF that accepts ManagerID (2012: JobTitle) and returns all of that Managers (2012: JobTitle) Employee Information.
--a.LoginID
--b.Gender
--c.HireDate

GO
CREATE FUNCTION [dbo].[GetEmployeesUnderManager](@ManagerID VARCHAR(50))
RETURNS TABLE
AS
RETURN
(
    SELECT 
        LoginID,
        Gender,
        HireDate
    FROM 
        [HumanResources].[Employee]
    WHERE 
        JobTitle = @ManagerID
)
GO

select * FROM [dbo].[GetEmployeesUnderManager]('Engineering Manager');
